package com.example.chess;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

class Knight extends Piece {
    Knight(String _name, Resources r) {
        super(_name);
        this.value = 300;

        if (player == 0)
            image = BitmapFactory.decodeResource(r, R.drawable.w_kn);
        else
            image = BitmapFactory.decodeResource(r, R.drawable.b_kn);
    }

    @Override
    boolean isCorrectTurn(int playerTurn) {
        if (playerTurn % 2 == 0 && Character.isUpperCase(name.charAt(0)))
            return true;
        else if (playerTurn % 2 == 1 && Character.isLowerCase(name.charAt(0)))
            return true;
        else
            return false;
    }

    @Override
    boolean isLegalMove(int rowStart, int colStart, int rowEnd, int colEnd) {
        if (Math.abs(rowEnd - rowStart) == 1 && Math.abs(colEnd - colStart) == 2)
            return true;
        else if (Math.abs(rowEnd - rowStart) == 2 && Math.abs(colEnd - colStart) == 1 )
            return true;
        else
            return false;
    }

    @Override
    ArrayList<Integer> movePath(int rowStart, int colStart, int rowEnd, int colEnd) {
        ArrayList<Integer> path = new ArrayList<>();

        path.add(rowStart);
        path.add(colStart);

        //Knight jumps to end, has no path
        path.add(rowEnd);
        path.add(colEnd);

        return path;
    }

    @Override
    ArrayList<Integer[]> allLegalMoves(int rowStart, int colStart) {
        ArrayList<Integer[]> moveList = new ArrayList<>();
        Integer[][] knightMove = {{1, 2}, {2, 1}, {1, -2}, {2, -1}, {-1, 2}, {-2, 1}, {-1, -2}, {-2, -1}};

        for (Integer[] item: knightMove) {
            Integer[] move = {rowStart, colStart, rowStart + item[0], colStart + item[1]};
            //Prevent going out of bounds
            if (move[2] < 0 || move[2] > 7 || move[3] < 0 || move[3] > 7)
                continue;

            moveList.add(move);
        }

        return moveList;
    }

}
