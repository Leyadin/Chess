package com.example.chess;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

class King extends Piece {
    King(String _name, Resources r) {
        super(_name);
        this.value = 90000;

        if (player == 0)
            image = BitmapFactory.decodeResource(r, R.drawable.w_k);
        else
            image = BitmapFactory.decodeResource(r, R.drawable.b_k);
    }

    @Override
    boolean isCorrectTurn(int playerTurn) {
        if (playerTurn % 2 == 0 && Character.isUpperCase(name.charAt(0)))
            return true;
        else if (playerTurn % 2 == 1 && Character.isLowerCase(name.charAt(0)))
            return true;
        else
            return false;
    }

    @Override
    boolean isLegalMove(int rowStart, int colStart, int rowEnd, int colEnd) {
        //Normal move
        if (Math.abs(rowEnd - rowStart) <= 1 && Math.abs(colEnd - colStart) <= 1)
            return true;
        //Castle
        else if (hasNotMoved == true && rowStart == rowEnd
                && Math.abs(colEnd - colStart) == 2)
            return true;
        else
            return false;
    }

    @Override
    ArrayList<Integer> movePath(int rowStart, int colStart, int rowEnd, int colEnd) {
        ArrayList<Integer> path = new ArrayList<>();

        path.add(rowStart);
        path.add(colStart);

        //King castles
        if (Math.abs(colEnd - colStart) == 2) {
            //Right
            for (int i = colStart + 1; i <= colEnd; i++) {
                path.add(rowStart);
                path.add(i);
            }

            //Left
            for (int i = colStart - 1; i >= colEnd; i--) {
                path.add(rowStart);
                path.add(i);
            }

            return path;
        }

        //King moves one square normally
        path.add(rowEnd);
        path.add(colEnd);

        return path;
    }

    ArrayList<Integer[]> allLegalMoves(int rowStart, int colStart) {
        ArrayList<Integer[]> moveList = new ArrayList<>();
        Integer[][] kingMove = {{1, 1}, {1, 0}, {1, -1}, {0, 1}, {0, -1}, {-1, 1}, {-1, 0}, {-1, -1}};

        for (Integer[] item: kingMove) {
            Integer[] move = {rowStart, colStart, rowStart + item[0], colStart + item[1]};
            //Prevent going out of bounds
            if (move[2] < 0 || move[2] > 7 || move[3] < 0 || move[3] > 7)
                continue;

            moveList.add(move);
        }

        if (hasNotMoved && colStart == 4 && (rowStart == 0 || rowStart == 7)) {
            Integer[] move = {rowStart, colStart, rowStart, colStart - 2};
            Integer[] move2 = {rowStart, colStart, rowStart, colStart + 2};
            moveList.add(move);
            moveList.add(move2);
        }

        return moveList;
    }

}
