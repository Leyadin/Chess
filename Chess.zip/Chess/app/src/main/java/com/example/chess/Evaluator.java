package com.example.chess;

class Evaluator {
    private Square[][] board;
    private int numPieces;
    //Note: use (7 - row) for black
    private int[][] pawnOffset = {
            {800, 800, 800, 800, 800, 800, 800, 800},
            {50, 50, 50, 50, 50, 50, 50, 50},
            {10, 10, 20, 30, 30, 20, 10, 10},
            {5, 5, 10, 25, 25, 10, 5, 5},
            {0, -10, 0, 20, 20, 0, -10, 0},
            {0, -10, -10, 0, 0, -10, -10, 0},
            {5, 25, 25, -15, -15, 25, 25, 5},
            {0, 0, 0, 0, 0, 0, 0, 0}};
    //Note: use (7 - row) for black
    private int[][] kingOffsetEarly = {
            {-30, -40, -40, -50, -50, -40, -40, -30},
            {-30, -40, -40, -50, -50, -40, -40, -30},
            {-30, -40, -40, -50, -50, -40, -40, -30},
            {-30, -40, -40, -50, -50, -40, -40, -30},
            {-20, -30, -30, -40, -40, -30, -30, -20},
            {-10, -20, -20, -20, -20, -20, -20, -10},
            {20, 20, 0, 0, 0, 0, 20, 20},
            {20, 30, 10, 0, 0, 10, 30, 20}};
    private int[][] kingOffsetLate = {
            {-50, -30, -30, -20, -20, -30, -30, -50},
            {-30, -20, -20, 0, 0, -20, -20, -30},
            {-30, -20, 0, 10, 10, 0, -20, -30},
            {-20, 0, 10, 20, 20, 10, 0, -20},
            {-20, 0, 10, 20, 20, 10, 0, -20},
            {-30, -20, 0, 10, 10, 0, -20, -30},
            {-30, -20, -20, 0, 0, -20, -20, -30},
            {-50, -30, -30, -20, -20, -30, -30, -50}};
    private int[][] queenOffset = {
            {-20, -10, -10, -5, -5, -10, -10, -20},
            {-10, 0, 0, 0, 0, 0, 0, -10},
            {-10, 0, 5, 5, 5, 5, 0, -10},
            {-5, 0, 5, 5, 5, 5, 0, -5},
            {-5, 0, 5, 5, 5, 5, 0, -5},
            {-10, 0, 5, 5, 5, 5, 0, -10},
            {-10, 0, 0, 0, 0, 0, 0, -10},
            {-20, -10, -10, -5, -5, -10, -10, -20}};
    private int[][] bishopOffset = {
            {-20, -10, -10, -10, -10, -10, -10, -20},
            {-10, 5, 0, 0, 0, 0, 5, -10},
            {-10, 0, 5, 10, 10, 5, 0, -10},
            {-10, 5, 5, 10, 10, 5, 5, -10},
            {-10, 5, 5, 10, 10, 5, 5, -10},
            {-10, 0, 5, 10, 10, 5, 0, -10},
            {-10, 5, 0, 0, 0, 0, 5, -10},
            {-20, -10, -10, -10, -10, -10, -10, -20}};
    private int[][] knightOffset = {
            {-50, -20, -20, -20, -20, -20, -20, -50},
            {-40, -20, 0, 5, 5, 0, -20, -40},
            {-30, 0, 15, 15, 15, 15, 0, -30},
            {-30, 5, 15, 20, 20, 15, 5, -30},
            {-30, 5, 15, 20, 20, 15, 5, -30},
            {-30, 0, 15, 15, 15, 15, 0, -30},
            {-40, -20, 0, 5, 5, 0, -20, -40},
            {-50, -20, -20, -20, -20, -20, -20, -50}};
    //Note: Use (7 - row) for black
    private int[][] rookOffset = {
            {0, 0, 0, 0, 0, 0, 0, 0},
            {5, 10, 10, 10, 10, 10, 10, 5},
            {-15, 0, 0, 0, 0, 0, 0, -15},
            {-5, 0, 0, 0, 0, 0, 0, -5},
            {-5, 0, 0, 0, 0, 0, 0, -5},
            {-15, 0, 0, 0, 0, 0, 0, -15},
            {-15, 0, 0, 0, 0, 0, 0, -15},
            {0, 0, 5, 10, 10, 5, 0, 0}};

    Evaluator() {

    }

    int evaluate(Square[][] _board, int _numPieces) {
        this.board = _board;
        this.numPieces = _numPieces;
        return scoreBoard();
    }

    private int scoreBoard() {
        int score = 0;

        for (int row = 0; row < 8; row++)
            for (int col = 0; col < 8; col++) {
                if (!board[row][col].isOccupied())
                    continue;

                if (board[row][col].piece.player == 0) {
                    score += board[row][col].piece.value;
                    score += offsetBonus(row, col);
                }
                else {
                    score -= board[row][col].piece.value;
                    score -= offsetBonus(row, col);
                }
            }

        return score;
    }

    private int offsetBonus(int row, int col) {
        switch (board[row][col].piece.getName()) {
            case "P" : return pawnOffset[row][col];
            case "p" : return pawnOffset[7 - row][col];
            case "K" :
                if (numPieces > 10)
                    return kingOffsetEarly[row][col];
                else
                    return kingOffsetLate[row][col];
            case "k" :
                if (numPieces > 10)
                    return kingOffsetEarly[7 - row][col];
                else
                    return kingOffsetLate[7 - row][col];
            case "Q" :
            case "q" : return queenOffset[row][col];
            case "R" : return rookOffset[row][col];
            case "r" : return rookOffset[7 - row][col];
            case "KN" :
            case "kn" : return knightOffset[row][col];
            case "B" :
            case "b" : return bishopOffset[row][col];
            default: return 0;
        }
    }

    int pawnStructure() {
        int points = 0;

        //Stacked pawns
        for (int row = 1; row < 7; row++) {
            for (int col = 0; col < 8; col++) {
                if (!board[row][col].isOccupied())
                    continue;

                //White
                if (board[row][col].getPiece().equals("P")) {
                    for (int rowCheck = 1; rowCheck < 7; rowCheck++) {
                        if (row == rowCheck)
                            continue;

                        if (board[rowCheck][col].getPiece().equals("P")) {
                            points -= 25;
                        }
                    }
                }
                //Black
                if (board[row][col].getPiece().equals("p")) {
                    //Check for stacked pawns
                    for (int rowCheck = 1; rowCheck < 7; rowCheck++) {

                        if (row == rowCheck)
                            continue;

                        if (board[rowCheck][col].getPiece().equals("p"))
                            points += 25;
                    }
                }
            }
        }

        //Connected pawns
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                if (!board[row][col].isOccupied())
                    continue;

                //White
                if (board[row][col].getPiece().equals("P")) {
                    for (int rowCheck = row - 1; rowCheck <= row + 1; rowCheck++) {
                        for (int colCheck = col - 1; colCheck <= col + 1; colCheck++) {
                            if (rowCheck < 0 || rowCheck > 7 || colCheck < 0 || colCheck > 7)
                                continue;

                            if (rowCheck == row && colCheck == col)
                                continue;

                            if (board[rowCheck][colCheck].getPiece().equals("P")) {
                                points += 5;
                            }
                        }
                    }
                }
                //Black
                if (board[row][col].getPiece().equals("p")) {
                    for (int rowCheck = row - 1; rowCheck <= row + 1; rowCheck++) {
                        for (int colCheck = col - 1; colCheck <= col + 1; colCheck++) {
                            if (rowCheck < 0 || rowCheck > 7 || colCheck < 0 || colCheck > 7)
                                continue;

                            if (rowCheck == row && colCheck == col)
                                continue;

                            if (board[rowCheck][colCheck].getPiece().equals("p"))
                                points -= 5;
                        }
                    }
                }
            }
        }

        return points;
    }
}
