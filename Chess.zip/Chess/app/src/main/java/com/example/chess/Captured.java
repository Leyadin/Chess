package com.example.chess;

import android.util.Pair;

import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;

class Captured {
    ArrayList<Pair<Square, Integer>> pieces;

    Captured() {
        pieces = new ArrayList<>();
    }

    void addPiece(Piece p, Integer turn) {
        Square temp = new Square(-1, -1);
        temp.piece = p;
        pieces.add(new Pair<>(temp, turn));

        //Comparator - sorts by ascending piece value
        class pieceOrder implements Comparator<Pair<Square, Integer>>
        {
            public int compare(Pair<Square, Integer> a, Pair<Square, Integer> b)
            {
                return b.first.piece.value - a.first.piece.value;
            }
        }

        Collections.sort(pieces, new pieceOrder());
    }
}