package com.example.chess;

import android.util.Pair;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Book {
    ArrayList<Integer[]> moveList;

    Book(ArrayList<Integer[]> _moveList) {
        this.moveList = _moveList;
    }

    Pair<Integer[], Integer> blackFirst() {
        Random rand = new Random();

        //Queen's pawn
        if (Arrays.toString(moveList.get(0)).equals("[6, 3, 4, 3]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {0, 6, 2, 5};
            Integer[] move2 = {1, 3, 3, 3};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
        }
        //Kings's pawn
        if (Arrays.toString(moveList.get(0)).equals("[6, 4, 4, 4]")) {
            int num = rand.nextInt(3);
            Integer[] move1 = {1, 2, 3, 2};
            Integer[] move2 = {1, 4, 2, 4};
            Integer[] move3 = {1, 4, 3, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
            else if (num == 2)
                return new Pair<>(move3, 0);
        }
        //Reti
        if (Arrays.toString(moveList.get(0)).equals("[7, 6, 5, 5]")) {
            int num = rand.nextInt(3);
            Integer[] move1 = {0, 6, 2, 5};
            Integer[] move2 = {1, 3, 3, 3};
            Integer[] move3 = {1, 2, 3, 2};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
            else if (num == 2)
                return new Pair<>(move3, 0);
        }
        //English
        if (Arrays.toString(moveList.get(0)).equals("[6, 2, 4, 2]")) {
            int num = rand.nextInt(4);
            Integer[] move1 = {0, 6, 2, 5};
            Integer[] move2 = {1, 4, 3, 4};
            Integer[] move3 = {1, 2, 3, 2};
            Integer[] move4 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
            else if (num == 2)
                return new Pair<>(move3, 0);
            else if (num == 3)
                return new Pair<>(move4, 0);
        }

        //If not in book, return null
        return null;
    }

    Pair<Integer[], Integer> blackSecond() {
        Random rand = new Random();

        //Queen's pawn - Indian game : 2.c4
        if (Arrays.toString(moveList.get(0)).equals("[6, 3, 4, 3]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 3, 3, 3]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 2, 4, 2]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {1, 2, 2, 2};
            Integer[] move2 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);

        }
        //Queen's pawn - Indian game: Knights variation
        if (Arrays.toString(moveList.get(0)).equals("[6, 3, 4, 3]") &&
                Arrays.toString(moveList.get(1)).equals("[0, 6, 2, 5]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 2, 4, 2]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {1, 6, 2, 6};
            Integer[] move2 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);

        }
        //Queen's pawn - Indian game: Knights variation
        if (Arrays.toString(moveList.get(0)).equals("[6, 3, 4, 3]") &&
                Arrays.toString(moveList.get(1)).equals("[0, 6, 2, 5]") &&
                Arrays.toString(moveList.get(2)).equals("[7, 1, 5, 2]")) {
            Integer[] move1 = {1, 3, 3, 3};
            return new Pair<>(move1, 0);
        }
        //Kings's pawn - Sicilian
        if (Arrays.toString(moveList.get(0)).equals("[6, 4, 4, 4]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 2, 3, 2]") &&
                Arrays.toString(moveList.get(2)).equals("[7, 6, 5, 5]")) {
            int num = rand.nextInt(3);
            Integer[] move1 = {1, 3, 2, 3};
            Integer[] move2 = {0, 1, 2, 2};
            Integer[] move3 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
            else if (num == 2)
                return new Pair<>(move3, 0);
        }
        //Kings's pawn - King's knight
        if (Arrays.toString(moveList.get(0)).equals("[6, 4, 4, 4]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 4, 3, 4]") &&
                Arrays.toString(moveList.get(2)).equals("[7, 6, 5, 5]")) {

            Integer[] move1 = {0, 1, 2, 2};
            return new Pair<>(move1, 0);
        }
        //Kings's pawn - French defense
        if (Arrays.toString(moveList.get(0)).equals("[6, 4, 4, 4]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 4, 2, 4]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 3, 4, 3]")) {

            Integer[] move1 = {1, 3, 3, 3};
            return new Pair<>(move1, 0);
        }
        //Reti - 2.KNf2
        if (Arrays.toString(moveList.get(0)).equals("[7, 6, 5, 5]")&&
                Arrays.toString(moveList.get(1)).equals("[0, 6, 2, 5]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 3, 4, 3]")) {
            int num = rand.nextInt(3);
            Integer[] move1 = {1, 3, 3, 3};
            Integer[] move2 = {1, 6, 2, 6};
            Integer[] move3 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
            else if (num == 2)
                return new Pair<>(move3, 0);
        }
        //Reti - 2.d4
        if (Arrays.toString(moveList.get(0)).equals("[7, 6, 5, 5]")&&
                Arrays.toString(moveList.get(1)).equals("[1, 3, 3, 3]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 3, 4, 3]")) {
            Integer[] move1 = {0, 6, 2, 5};
            return new Pair<>(move1, 0);
        }
        //Reti - Sicilian
        if (Arrays.toString(moveList.get(0)).equals("[7, 6, 5, 5]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 2, 3, 2]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 4, 4, 4]")) {
            int num = rand.nextInt(3);
            Integer[] move1 = {1, 3, 2, 3};
            Integer[] move2 = {0, 1, 2, 2};
            Integer[] move3 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
            else if (num == 2)
                return new Pair<>(move3, 0);
        }
        //English - Indian game
        if (Arrays.toString(moveList.get(0)).equals("[6, 2, 4, 2]") &&
                Arrays.toString(moveList.get(1)).equals("[0, 6, 2, 5]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 3, 4, 3]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {1, 6, 2, 6};
            Integer[] move2 = {1, 4, 2, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
        }
        //English - King's English
        if (Arrays.toString(moveList.get(0)).equals("[6, 2, 4, 2]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 4, 3, 4]") &&
                Arrays.toString(moveList.get(2)).equals("[7, 1, 5, 2]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {0, 1, 2, 2};
            Integer[] move2 = {0, 6, 2, 5};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
        }
        //English - Anglo-Indian game
        if (Arrays.toString(moveList.get(0)).equals("[6, 2, 4, 2]") &&
                Arrays.toString(moveList.get(1)).equals("[0, 6, 2, 5]") &&
                Arrays.toString(moveList.get(2)).equals("[7, 1, 5, 2]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {1, 2, 3, 2};
            Integer[] move2 = {1, 4, 3, 4};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
        }
        //English - Agincourt defense
        if (Arrays.toString(moveList.get(0)).equals("[6, 2, 4, 2]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 4, 2, 4]") &&
                Arrays.toString(moveList.get(2)).equals("[6, 3, 4, 3]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {0, 6, 2, 5};
            Integer[] move2 = {1, 3, 3, 3};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
        }
        //English - Symmetrical variation
        if (Arrays.toString(moveList.get(0)).equals("[6, 2, 4, 2]") &&
                Arrays.toString(moveList.get(1)).equals("[1, 2, 3, 2]") &&
                Arrays.toString(moveList.get(2)).equals("[7, 6, 5, 5]")) {
            int num = rand.nextInt(2);
            Integer[] move1 = {0, 1, 2, 2};
            Integer[] move2 = {0, 6, 2, 5};
            if (num == 0)
                return new Pair<>(move1, 0);
            else if (num == 1)
                return new Pair<>(move2, 0);
        }


        return null;
    }
}