package com.example.chess;
import android.graphics.Bitmap;

import java.util.ArrayList;

abstract class Piece {
    //Used for engine and sorting
    Integer value;
    //Capitals are light, lowercase are dark
    String name;
    //Flag for if the piece has moved or not
    boolean hasNotMoved;
    //Which player owns the piece (0 - white, 1 - black)
    int player;
    //Graphic
    Bitmap image;

    Piece(String _name) {
        this.hasNotMoved = true;
        this.name = _name;

        if (Character.isUpperCase(name.charAt(0)))
            this.player = 0;
        else
            this.player = 1;
    }

    //Does the player control this piece
    abstract boolean isCorrectTurn(int playerTurn);
    //Check if legal move based on piece type
    //Color is for pawn only
    abstract boolean isLegalMove(int rowStart, int colStart, int rowEnd, int colEnd);
    //Create a list of each (row, col) pairs to get to destination square
    //row has odd index, col have even index
    abstract ArrayList<Integer> movePath(int rowStart, int colStart, int rowEnd, int colEnd);
    //Display name
    String getName() {return name;}
    //All possible legal moves for the piece
    abstract ArrayList<Integer[]> allLegalMoves(int rowStart, int colStart);
}
