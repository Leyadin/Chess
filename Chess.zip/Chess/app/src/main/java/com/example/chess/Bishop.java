package com.example.chess;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

class Bishop extends Piece {
    Bishop(String _name, Resources r) {
        super(_name);
        this.value = 315;

        if (player == 0)
            image = BitmapFactory.decodeResource(r, R.drawable.w_b);
        else
            image = BitmapFactory.decodeResource(r, R.drawable.b_b);
    }

    @Override
    boolean isCorrectTurn(int playerTurn) {
        if (playerTurn % 2 == 0 && Character.isUpperCase(name.charAt(0)))
            return true;
        else if (playerTurn % 2 == 1 && Character.isLowerCase(name.charAt(0)))
            return true;
        else
            return false;
    }

    @Override
    boolean isLegalMove(int rowStart, int colStart, int rowEnd, int colEnd) {
        if (rowEnd - colEnd == rowStart - colStart)
            return true;
        else if (rowEnd + colEnd == rowStart + colStart)
            return true;
        else
            return false;
    }

    @Override
    ArrayList<Integer> movePath(int rowStart, int colStart, int rowEnd, int colEnd) {
        ArrayList<Integer> path = new ArrayList<>();
        int currentCol = colStart;

        path.add(rowStart);
        path.add(colStart);

        //Up-Right
        if (rowEnd > rowStart && colEnd > colStart) {
            for (int i = rowStart + 1; i <= rowEnd; i++) {
                ++currentCol;
                path.add(i);
                path.add(currentCol);
            }
        }
        //Up-Left
        else if (rowEnd > rowStart && colEnd < colStart) {
            for (int i = rowStart + 1; i <= rowEnd; i++) {
                --currentCol;
                path.add(i);
                path.add(currentCol);
            }
        }
        //Down-Right
        else if (rowEnd < rowStart && colEnd > colStart) {
            for (int i = rowStart - 1; i >= rowEnd; i--) {
                ++currentCol;
                path.add(i);
                path.add(currentCol);
            }
        }
        //Down-Left
        else if (rowEnd < rowStart && colEnd < colStart) {
            for (int i = rowStart - 1; i >= rowEnd; i--) {
                --currentCol;
                path.add(i);
                path.add(currentCol);
            }
        }

        return path;
    }

    @Override
    ArrayList<Integer[]> allLegalMoves(int rowStart, int colStart) {
        ArrayList<Integer[]> moveList = new ArrayList<>();

        //Up-Right
        for (int rowEnd = rowStart + 1, colEnd = colStart + 1;
             rowEnd <= 7 && colEnd <= 7; rowEnd++, colEnd++) {
            Integer[] move = {rowStart, colStart, rowEnd, colEnd};
            moveList.add(move);
        }
        //Up-Left
        for (int rowEnd = rowStart + 1, colEnd = colStart - 1;
             rowEnd <= 7 && colEnd >= 0; rowEnd++, colEnd--) {
            Integer[] move = {rowStart, colStart, rowEnd, colEnd};
            moveList.add(move);
        }
        //Down-Right
        for (int rowEnd = rowStart - 1, colEnd = colStart + 1;
             rowEnd >= 0 && colEnd <= 7; rowEnd--, colEnd++) {
            Integer[] move = {rowStart, colStart, rowEnd, colEnd};
            moveList.add(move);
        }
        //Down-Left
        for (int rowEnd = rowStart - 1, colEnd = colStart - 1;
             rowEnd >= 0 && colEnd >= 0; rowEnd--, colEnd--) {
            Integer[] move = {rowStart, colStart, rowEnd, colEnd};
            moveList.add(move);
        }

        return moveList;
    }
}
