package com.example.chess;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

class Rook extends Piece {
    Rook(String _name, Resources r) {
        super(_name);
        this.value = 500;

        if (player == 0)
            image = BitmapFactory.decodeResource(r, R.drawable.w_r);
        else
            image = BitmapFactory.decodeResource(r, R.drawable.b_r);
    }

    @Override
    boolean isCorrectTurn(int playerTurn) {
        if (playerTurn % 2 == 0 && Character.isUpperCase(name.charAt(0)))
            return true;
        else if (playerTurn % 2 == 1 && Character.isLowerCase(name.charAt(0)))
            return true;
        else
            return false;
    }

    @Override
    boolean isLegalMove(int rowStart, int colStart, int rowEnd, int colEnd) {
        if (rowEnd == rowStart || colEnd == colStart)
            return true;
        else
            return false;
    }

    @Override
    ArrayList<Integer> movePath(int rowStart, int colStart, int rowEnd, int colEnd) {
        ArrayList<Integer> path = new ArrayList<>();

        path.add(rowStart);
        path.add(colStart);

        if(colStart == colEnd) {
            //Up
            for (int i = rowStart + 1; i <= rowEnd; i++) {
                path.add(i);
                path.add(colStart);
            }

            //Down
            for (int i = rowStart - 1; i >= rowEnd; i--) {
                path.add(i);
                path.add(colStart);
            }
        }
        else {
            //Right
            for (int i = colStart + 1; i <= colEnd; i++) {
                path.add(rowStart);
                path.add(i);
            }

            //Left
            for (int i = colStart - 1; i >= colEnd; i--) {
                path.add(rowStart);
                path.add(i);
            }
        }

        return path;
    }

    @Override
    ArrayList<Integer[]> allLegalMoves(int rowStart, int colStart) {
        ArrayList<Integer[]> moveList = new ArrayList<>();

        //Up
        for (int rowEnd = rowStart + 1; rowEnd <= 7; rowEnd++) {
            Integer[] move = {rowStart, colStart, rowEnd, colStart};
            moveList.add(move);
        }
        //Down
        for (int rowEnd = rowStart - 1; rowEnd >= 0; rowEnd--) {
            Integer[] move = {rowStart, colStart, rowEnd, colStart};
            moveList.add(move);
        }
        //Right
        for (int colEnd = colStart + 1; colEnd <= 7; colEnd++) {
            Integer[] move = {rowStart, colStart, rowStart, colEnd};
            moveList.add(move);
        }
        //Left
        for (int colEnd = colStart - 1; colEnd >= 0; colEnd--) {
            Integer[] move = {rowStart, colStart, rowStart, colEnd};
            moveList.add(move);
        }

        return moveList;
    }
}
