package com.example.chess;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.util.Pair;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

public class Board extends View {
    MediaPlayer mediaPlayer;
    private static final int ROWS = 8, COLS = 8;
    int playerTurn;
    int checkCode;
    int[] whiteKing, blackKing;
    boolean gameOver, promotionChoice, captureFlag;
    int[] enPassant = {-1, -1, -1};
    ArrayList<Integer[]> allLegalMoves;
    ArrayList<Pair<Integer[], Integer>> allValidMoves;
    Integer[] currentTurn;
    ArrayList<Integer[]> moveList;
    Square[][] board = new Square[ROWS][COLS];
    Square[] promotionWhite, promotionBlack;
    TreeMap<Integer, Piece> promotionTrack = new TreeMap<>();
    Captured whiteCaptured, blackCaptured;
    int vsComputer;
    ArrayList<Integer> moveScores = new ArrayList<>();
    Evaluator eval;
    boolean lockScreen;

    public Board(Context context) {
        super(context);
        init();
    }

    public void init() {
        //Keep track of current state of check
        checkCode = 0;
        //Keep track of white king position {row, col}
        whiteKing = new int[2];
        //Keep track of black king position {row, col}
        blackKing = new int[2];
        //Flag for pawn promotion
        promotionChoice = false;
        //Flag for game over
        gameOver = false;
        //Keeps track of how many moves have been made
        playerTurn = 0;
        //Turn off computer
        vsComputer = 0;
        //Prevent screen interaction while computer is working
        lockScreen = false;

        Resources resources = getResources();
        //Setup the board
        generateBoard();
        setPieces(resources);

        //Promotion setup
        promotionWhite = new Square[4];
        promotionBlack = new Square[4];
        generatePromotionBoard(resources);

        //Generate a list of all legal moves
        allLegalMoves = legalMoves();
        //Generate a list of all valid moves
        allValidMoves = validMoves(allLegalMoves);

        //The first element -1 is a flag for new turn
        //{startRow, startCol, endRow, endCol}
        currentTurn = new Integer[]{-1, -1,-1, -1};
        //Keep track of all moves
        moveList = new ArrayList<>();

        //Keep track of captured pieces
        whiteCaptured = new Captured();
        blackCaptured = new Captured();

        //Play game start sound
        mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_startgame);
        mediaPlayer.start();
    }

    void computerOn() {
        //Set computer depth
        vsComputer = 4;
        eval = new Evaluator();
    }

    private void generateBoard() {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                board[row][col] = new Square(row, col);
            }
        }
    }

    private void setPieces(Resources r) {
        //Black
        for (int col = 0; col < COLS; col++) {
            board[1][col].piece = new Pawn("p", r);
        }
        board[0][0].piece = new Rook("r", r);
        board[0][1].piece = new Knight("kn", r);
        board[0][2].piece = new Bishop("b", r);
        board[0][3].piece = new Queen("q", r);
        board[0][4].piece = new King("k", r);
        board[0][5].piece = new Bishop("b", r);
        board[0][6].piece = new Knight("kn", r);
        board[0][7].piece = new Rook("r", r);
        blackKing[0] = 0;
        blackKing[1] = 4;

        //White
        for (int col = 0; col < COLS; col++) {
            board[6][col].piece = new Pawn("P", r);
        }
        board[7][0].piece = new Rook("R", r);
        board[7][1].piece = new Knight("KN", r);
        board[7][2].piece = new Bishop("B", r);
        board[7][3].piece = new Queen("Q", r);
        board[7][4].piece = new King("K", r);
        board[7][5].piece = new Bishop("B", r);
        board[7][6].piece = new Knight("KN", r);
        board[7][7].piece = new Rook("R", r);
        whiteKing[0] = 7;
        whiteKing[1] = 4;
    }

    //Pre-generate the promotion choices
    private void generatePromotionBoard(Resources r) {
        promotionWhite[0] = new Square(0,1);
        promotionWhite[0].piece = new Knight("KN", r);
        promotionWhite[1] = new Square(0,1);
        promotionWhite[1].piece = new Bishop("B", r);
        promotionWhite[2] = new Square(0,1);
        promotionWhite[2].piece = new Rook("R", r);
        promotionWhite[3] = new Square(0,1);
        promotionWhite[3].piece = new Queen("Q", r);

        promotionBlack[0] = new Square(0,1);
        promotionBlack[0].piece = new Knight("kn", r);
        promotionBlack[1] = new Square(0,1);
        promotionBlack[1].piece = new Bishop("b", r);
        promotionBlack[2] = new Square(0,1);
        promotionBlack[2].piece = new Rook("r", r);
        promotionBlack[3] = new Square(0,1);
        promotionBlack[3].piece = new Queen("q", r);
    }

    //Primary function
    //All game play is executed here
    void playGame(final int touchX, final int touchY) {
        if (mediaPlayer != null)
            mediaPlayer.release();

        //Freeze the game state if game is over
        if (gameOver)
            return;

        //Deal with pawn promotion
        if (promotionChoice) {
            promote(touchX, touchY);
            if (vsComputer > 0 && playerTurn % 2 == 1)
                computerTurn();
            return;
        }

        //First half of move: select piece
        if (currentTurn[0] == -1) {
            Pair<Integer, Integer> squareCoords = squareTouched(touchX, touchY);
            int row = squareCoords.first;
            int col = squareCoords.second;

            //Leave function if no square was touched
            if(row == -1)
                return;

            //Check if square is occupied and the piece belongs to current player
            //Leave function if either is not true
            if (!board[row][col].isOccupied() ||
                    !board[row][col].piece.isCorrectTurn(playerTurn))
                return;

            //Highlight square
            board[row][col].highlight();

            //Store first half of current move
            currentTurn[0] = row;
            currentTurn[1] = col;
        }
        //Second half of move: move piece
        else {
            Pair<Integer, Integer> squareCoords = squareTouched(touchX, touchY);

            //Leave function if no square was touched
            if(squareCoords.first == -1)
                return;

            //Store second half of move
            currentTurn[2] = squareCoords.first;
            currentTurn[3] = squareCoords.second;
            //More convenient variables
            int startRow = currentTurn[0];
            int startCol = currentTurn[1];
            int endRow = currentTurn[2];
            int endCol = currentTurn[3];
            String currentPiece = board[startRow][startCol].piece.getName();

            //Unhighlight if re-selecting the same square
            if (startRow == endRow && startCol == endCol) {
                board[endRow][endCol].unhighlight();
                currentTurn[0] = -1;
                //Keep the king red if it is currently in check
                if (checkCode == 2) {
                    board[whiteKing[0]][whiteKing[1]].colorChecked();
                }
                else if (checkCode == 3) {
                    board[blackKing[0]][blackKing[1]].colorChecked();
                }
                return;
            }

            //Check if move is valid
            boolean validMove = false;
            for (Pair<Integer[], Integer> item: allValidMoves) {
                if (Arrays.equals(currentTurn, item.first)) {
                    validMove = true;
                    checkCode = item.second;
                }
            }
            //Exit function if not a valid move
            if (!validMove)
                return;

            movePiece(startRow, startCol, endRow, endCol, currentPiece);

            //Flag pawn promotion
            if ((currentPiece.equals("P") || currentPiece.equals("p")) &&
                    (endRow == 0 || endRow == 7)) {
                promotionChoice = true;
            }

            //Unhighlight previous move
            if (playerTurn > 0) {
                board[moveList.get(playerTurn - 1)[0]][moveList.get(playerTurn - 1)[1]].unhighlight();
                board[moveList.get(playerTurn - 1)[2]][moveList.get(playerTurn - 1)[3]].unhighlight();
            }
            //Highlight move
            colorCheck();
            board[startRow][startCol].highlight();
            board[endRow][endCol].highlight();


            //Turn enPassant flag off
            if (enPassant[2] != playerTurn) {
                enPassant[0] = -1;
                enPassant[1] = -1;
                enPassant[2] = -1;
            }

            //Remove ghost moves if back function has been used
            while (moveList.size() > playerTurn) {
                moveList.remove(moveList.size() - 1);
            }

            //Remove ghost promotions
            promotionTrack.tailMap(playerTurn + 1).clear();

            //Add the move to moveList
            moveList.add(Arrays.copyOf(currentTurn, 4));

            //Reset to selecting a piece
            currentTurn[0] = -1;

            playerTurn++;
            //Update the legal moves list
            allLegalMoves = legalMoves();
            //Update the valid moves list
            allValidMoves = validMoves(allLegalMoves);

            //Check if game is over
            gameOver = isGameOver();

            //Plays sound effect
            playSound();

            //Exit function if game over (This skips computer trying to take a turn)
            if (gameOver) {
                if (checkCode == 0)
                    endGameMessage("Draw!");
                else
                    endGameMessage("Checkmate!");

                return;
            }

            //Redraw if there is a pending promotion
            if (promotionChoice) {
                this.invalidate();
            }

            //Computer makes its move
            else if (vsComputer > 0 && playerTurn % 2 == 1) {
                this.invalidate();

                //Update UI before calculating computer turn
                Timer timer = new Timer();
                TimerTask t = new TimerTask() {
                    @Override
                    public void run() {
                        lockScreen = true;
                        computerTurn();
                        lockScreen = false;
                    }
                };
                timer.schedule(t, 250);
            }
        }
    }

    //Check if a move is valid
    private boolean checkValidMove(ArrayList<Integer> movePath, String currentPiece) {
        int arrSize = movePath.size();
        //First two values are the piece's current square
        for (int i = 2; i < arrSize; i += 2) {
            //If there is no piece on the square being checked, go to next square
            if (!board[movePath.get(i)][movePath.get(i+1)].isOccupied()) {
                continue;
            }
            else {
                //If there is a piece in the way and it's not the ending square
                //return false
                if (i + 2 < arrSize)
                    return false;

                //If the piece at the end is owned by the same player
                //return false
                int playerControls = board[movePath.get(i)][movePath.get(i+1)].piece.player;
                if (playerTurn % 2 == playerControls)
                    return false;

                //Pawn - Can only capture diagonally
                if (currentPiece.equals("p") || currentPiece.equals("P"))
                    if (movePath.get(1).equals(movePath.get(3)))
                        return false;
            }
        }

        //Pawn - Prevent moving diagonally without a capture
        //White
        if (currentPiece.equals("P"))
            if (!movePath.get(1).equals(movePath.get(3)) &&
                    !board[movePath.get(2)][movePath.get(3)].isOccupied()) {
                //En passant
                if (enPassant[0] == (movePath.get(2) + 1) && enPassant[1] == movePath.get(3))
                    return true;
                else
                    return false;
            }
        //Black
        if (currentPiece.equals("p"))
            if (!movePath.get(1).equals(movePath.get(3)) &&
                    !board[movePath.get(2)][movePath.get(3)].isOccupied()) {
                //En passant
                if (enPassant[0] == (movePath.get(2) - 1) && enPassant[1] == movePath.get(3))
                    return true;
                else
                    return false;
            }

        //Castling
        if ((currentPiece.equals("K") || currentPiece.equals("k")) && arrSize == 6)
            return (attemptCastle(movePath.get(0), movePath.get(1), movePath.get(5)));

        return true;
    }

    //Returns true if castling is possible
    private boolean attemptCastle(int row, int startCol, int endCol) {
        //See if king has not moved yet
        if (!board[row][startCol].piece.hasNotMoved)
            return false;
        //Prevent castling out of check
        if (checkCode != 0)
            return false;

        //King's side
        if (startCol < endCol) {
            //See if the king side rook has not moved yet
            if (board[row][7].isOccupied() && board[row][7].piece.hasNotMoved) {
                //If the king passes through check, return false
                if(check(row, startCol, row, startCol + 1) == 1)
                    return false;

                return true;
            }
        }
        //Queen's side
        else {
            //See if the queen side rook has not moved yet
            if (board[row][0].isOccupied() && board[row][0].piece.hasNotMoved && !board[row][1].isOccupied()) {
                //If the king passes through check, return false
                if(check(row, startCol, row, startCol - 1) == 1)
                    return false;

                return true;
            }
        }

        return false;
    }

    //Moves the piece
    void movePiece(int startRow, int startCol, int endRow, int endCol, String currentPiece) {
        captureFlag = false;

        //Track the captured pieces
        if (board[endRow][endCol].isOccupied()) {
            capturePiece(endRow, endCol);
        }

        //Flag if the move will be a castle
        //      1 - King side castle
        //      2 - Queen side castle
        int castleFlag = 0;
        if (currentPiece.equals("K") || currentPiece.equals("k")) {
            if (endCol - startCol == 2)
                castleFlag = 1;
            else if (endCol - startCol == -2)
                castleFlag = 2;
        }

        if (castleFlag == 0) {
            //Move the piece
            board[startRow][startCol].piece.hasNotMoved = false;
            board[endRow][endCol].piece = board[startRow][startCol].piece;

            //Capture from en passant
            //White
            if (currentPiece.equals("P") && enPassant[2] != -1) {
                if (endRow == enPassant[0] - 1 && endCol == enPassant[1]) {
                    board[enPassant[0]][enPassant[1]].piece = null;
                    captureFlag = true;
                }
            }
            //Black
            if (currentPiece.equals("p") && enPassant[2] != -1) {
                if (endRow == enPassant[0] + 1 && endCol == enPassant[1]) {
                    board[enPassant[0]][enPassant[1]].piece = null;
                    captureFlag = true;
                }
            }

            //Turn enPassant flag on
            if ((currentPiece.equals("p") || currentPiece.equals("P")) && Math.abs(endRow - startRow) == 2) {
                enPassant[0] = endRow;
                enPassant[1] = endCol;
                enPassant[2] = playerTurn;
            }

            //Clear the square the piece was moved from
            board[startRow][startCol].piece = null;
        }
        //King side castle
        else if (castleFlag == 1) {
            checkCode = kingCastle(endRow);
        }
        //Queen side castle
        else if (castleFlag == 2) {
            checkCode = queenCastle(endRow);
        }

        //Update king position position
        if (currentPiece.equals("K") || currentPiece.equals("k")) {
            if (playerTurn % 2 == 0) {
                whiteKing[0] = endRow;
                whiteKing[1] = endCol;
            }
            else {
                blackKing[0] = endRow;
                blackKing[1] = endCol;
            }
        }
    }

    //King side castle
    //returns the checkCode
    int kingCastle (int endRow) {
        //Move king and set old square to null
        board[endRow][6].piece = board[endRow][4].piece;
        board[endRow][4].piece = null;
        board[endRow][6].piece.hasNotMoved = false;
        //Update the king position
        if (playerTurn % 2 == 0) {
            whiteKing[0] = endRow;
            whiteKing[1] = 6;
        }
        else {
            blackKing[0] = endRow;
            blackKing[1] = 6;
        }

        //See if the rook puts the enemy king in check
        int rookCheck = check(endRow, 7, endRow, 5);

        //Move rook and set old square to null
        board[endRow][5].piece = board[endRow][7].piece;
        board[endRow][7].piece = null;

        return rookCheck;
    }

    //Queen side castle
    //returns the checkCode
    int queenCastle (int endRow) {
        //Move king and set old square to null
        board[endRow][2].piece = board[endRow][4].piece;
        board[endRow][4].piece = null;
        board[endRow][2].piece.hasNotMoved = false;
        //Update the king position and highlight where it came from
        if (playerTurn % 2 == 0) {
            whiteKing[0] = endRow;
            whiteKing[1] = 2;
        }
        else {
            blackKing[0] = endRow;
            blackKing[1] = 2;
        }

        //See if the rook move puts the king in check
        int rookCheck = check(endRow, 0, endRow, 3);

        //Move rook and set old square to null
        board[endRow][3].piece = board[endRow][0].piece;
        board[endRow][0].piece = null;

        return rookCheck;
    }

    //Color the king's square based on checkCode
    void colorCheck() {
        //Remove red highlight if no check
        if (checkCode == 0) {
            board[whiteKing[0]][whiteKing[1]].uncolorChecked();
            board[blackKing[0]][blackKing[1]].uncolorChecked();
        }
        //Red highlight if white king in check
        if (checkCode == 2) {
            board[whiteKing[0]][whiteKing[1]].colorChecked();
            board[blackKing[0]][blackKing[1]].uncolorChecked();
        }
        //Red highlight if black king in check
        else if (checkCode == 3) {
            board[blackKing[0]][blackKing[1]].colorChecked();
            board[whiteKing[0]][whiteKing[1]].uncolorChecked();
        }
    }

    //return which square is touched
    //return (-1, -1) if no square is touched
    private Pair<Integer, Integer> squareTouched(int touchX, int touchY) {
        for (int row = 0; row < ROWS; row++)
            for (int col = 0; col < COLS; col++) {
                if (board[row][col].isTouched(touchX, touchY)) {
                    //Return the coordinates of a touched square
                    return new Pair<>(row, col);
                }
            }

        //Else return -1, -1 to signify no square was touched
        return new Pair<>(-1, -1);
    }

    //return 0 if no check
    //       1 if player ends in check (illegal move)
    //       2 if white king under check
    //       3 if black king under check
    int check(int curRow, int curCol, int testRow, int testCol) {
        ArrayList<Integer> movePath;
        String currentPiece;
        int isCheck = 0;
        int[] tempWhiteKing = {whiteKing[0], whiteKing[1]};
        int[] tempBlackKing = {blackKing[0], blackKing[1]};

        //Temporarily make the proposed move
        Piece tempPiece = board[testRow][testCol].piece;
        board[testRow][testCol].piece = board[curRow][curCol].piece;
        board[curRow][curCol].piece = null;
        //Temporarily update the king if the king is the piece moving
        if (board[testRow][testCol].piece.getName().equals("K")) {
            tempWhiteKing[0] = board[testRow][testCol].row;
            tempWhiteKing[1] = board[testRow][testCol].col;
        }
        else if (board[testRow][testCol].piece.getName().equals("k")) {
            tempBlackKing[0] = board[testRow][testCol].row;
            tempBlackKing[1] = board[testRow][testCol].col;
        }

        for (Square[] outer: board) {
            //Short circuit if the move will be illegal
            if (isCheck == 1)
                break;
            for (Square elem: outer) {
                //Short circuit if the move will be illegal
                if (isCheck == 1)
                    break;
                //Skip the square if no piece
                if (!elem.isOccupied())
                    continue;

                //White player checking if a black piece has white king in check
                if (playerTurn % 2 == 0 && elem.piece.player == 1) {
                    //Check to see if attacking the king is a legal move
                    if(elem.piece.isLegalMove(elem.row, elem.col, tempWhiteKing[0], tempWhiteKing[1])) {
                        //Check to see if attacking the king is a valid move
                        movePath = elem.piece.movePath(elem.row, elem.col, tempWhiteKing[0], tempWhiteKing[1]);
                        currentPiece = elem.piece.getName();
                        playerTurn++;
                        if (checkValidMove(movePath, currentPiece))
                            isCheck = 1;
                        playerTurn--;
                    }
                }
                //White player checking if white piece has black king in check
                else if (playerTurn % 2 == 0 && elem.piece.player == 0) {
                    if(elem.piece.isLegalMove(elem.row, elem.col, tempBlackKing[0], tempBlackKing[1])) {
                        movePath = elem.piece.movePath(elem.row, elem.col, tempBlackKing[0], tempBlackKing[1]);
                        currentPiece = elem.piece.getName();
                        if (checkValidMove(movePath, currentPiece))
                            isCheck = 3;
                    }
                }
                //Black player checking if black piece has white king in check
                else if (playerTurn % 2 == 1 && elem.piece.player == 1) {
                    if(elem.piece.isLegalMove(elem.row, elem.col, tempWhiteKing[0], tempWhiteKing[1])) {
                        movePath = elem.piece.movePath(elem.row, elem.col, tempWhiteKing[0], tempWhiteKing[1]);
                        currentPiece = elem.piece.getName();
                        if (checkValidMove(movePath, currentPiece))
                            isCheck = 2;
                    }
                }
                //Black player checking if white piece has black king in check
                else if (playerTurn % 2 == 1 && elem.piece.player == 0) {
                    if(elem.piece.isLegalMove(elem.row, elem.col, tempBlackKing[0], tempBlackKing[1])) {
                        movePath = elem.piece.movePath(elem.row, elem.col, tempBlackKing[0], tempBlackKing[1]);
                        currentPiece = elem.piece.getName();
                        playerTurn++;
                        if (checkValidMove(movePath, currentPiece))
                            isCheck = 1;
                        playerTurn--;
                    }
                }
            }
        }

        //Unmake the proposed move
        board[curRow][curCol].piece = board[testRow][testCol].piece;
        board[testRow][testCol].piece = tempPiece;

        return isCheck;
    }

    //Returns all legal moves
    ArrayList<Integer[]> legalMoves() {
        ArrayList<Integer[]> allLegalMoves = new ArrayList<>();

        for (Square[] outer: board) {
            for (Square elem : outer) {
                //Skip squares with no pieces
                if (!elem.isOccupied())
                    continue;

                allLegalMoves.addAll(elem.piece.allLegalMoves(elem.row, elem.col));
            }
        }

        return allLegalMoves;
    }

    //Returns all valid moves
    ArrayList<Pair<Integer[], Integer>> validMoves(ArrayList<Integer[]> legalMoves) {
        ArrayList<Pair<Integer[], Integer>> validMoves = new ArrayList<>();

        for (Integer[] item: legalMoves) {
            int startRow = item[0], startCol = item[1], endRow = item[2], endCol = item[3];
            //If the player does not control the piece, skip it
            if (playerTurn % 2 != board[startRow][startCol].piece.player)
                continue;

            //Get the move path for the move in question
            ArrayList<Integer> movePath = board[startRow][startCol].piece.movePath(startRow, startCol, endRow, endCol);

            //Check if it is a valid move
            if (checkValidMove(movePath, board[startRow][startCol].piece.getName())) {
                //Check the move's check interaction - record that code
                int checkCode = check(startRow, startCol, endRow, endCol);

                //Do not add the move if it puts the moving player in check
                if (checkCode != 1)
                    validMoves.add(new Pair<>(item, checkCode));
            }
        }

        return validMoves;
    }

    //Pawn promotion
    void promote(final int touchX, final int touchY) {
        int selection = -1;
        Piece promotion;

        //White
        if (promotionChoice && playerTurn % 2 == 1) {
            for (int col = 0; col < 4; col++) {
                if (promotionWhite[col].isTouched(touchX, touchY)) {
                    selection = col;
                }
            }
        }
        //Black
        else {
            for (int col = 0; col < 4; col++) {
                if (promotionBlack[col].isTouched(touchX, touchY)) {
                    selection = col;
                }
            }
        }

        //Exit function if no piece is selected
        if (selection == -1)
            return;

        if (playerTurn % 2 == 1)
            promotion = promotionWhite[selection].piece;
        else
            promotion = promotionBlack[selection].piece;

        //Set the pawn to the chosen piece
        board[moveList.get(playerTurn - 1)[2]][moveList.get(playerTurn - 1)[3]].piece = promotion;
        //Track the promotion for back/forward functions
        promotionTrack.put(playerTurn, promotion);

        //Test for if the promotion causes check by simulating
        //moving the chosen piece to the promotion square
        board[moveList.get(playerTurn - 1)[0]][moveList.get(playerTurn - 1)[1]].piece = promotion;
        checkCode = check(moveList.get(playerTurn - 1)[0], moveList.get(playerTurn - 1)[1],
                moveList.get(playerTurn - 1)[2], moveList.get(playerTurn - 1)[3]);
        board[moveList.get(playerTurn - 1)[0]][moveList.get(playerTurn - 1)[1]].piece = null;

        //Red highlight if black king in check
        //Note that checkCode is reversed due to when pawn promotion is checked
        if (checkCode == 1 && playerTurn % 2 == 1) {
            board[blackKing[0]][blackKing[1]].colorChecked();
            board[whiteKing[0]][whiteKing[1]].uncolorChecked();
            checkCode = 3;
            mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_check);
            mediaPlayer.start();
        }
        //Red highlight if white king in check
        else if (checkCode == 1 && playerTurn % 2 == 0) {
            board[whiteKing[0]][whiteKing[1]].colorChecked();
            board[blackKing[0]][blackKing[1]].uncolorChecked();
            checkCode = 2;
            mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_check);
            mediaPlayer.start();
        }

        //Update the legal moves list
        allLegalMoves = legalMoves();
        //Update the valid moves list
        allValidMoves = validMoves(allLegalMoves);

        promotionChoice = false;
    }

    //Capture a piece
    void capturePiece(int endRow, int endCol) {
        captureFlag = true;
        String capturedPieceName = board[endRow][endCol].piece.getName();
        int copyOfPiece = 0;

        if (board[endRow][endCol].piece.player == 0) {
            //Count how many of the target piece have already been captured
            for (Pair<Square, Integer> item: whiteCaptured.pieces) {
                if (item.first.piece.getName().equals(capturedPieceName))
                    copyOfPiece++;
            }

            //If there is already a Queen, two Bishops, two Knights, or two Rooks
            //Add a pawn instead
            if (capturedPieceName.equals("Q") && copyOfPiece == 2)
                whiteCaptured.addPiece(new Pawn("P", getResources()), playerTurn);
            else if (capturedPieceName.equals("B") && copyOfPiece == 3)
                whiteCaptured.addPiece(new Pawn("P", getResources()), playerTurn);
            else if (capturedPieceName.equals("KN") && copyOfPiece == 3)
                whiteCaptured.addPiece(new Pawn("P", getResources()), playerTurn);
            else if (capturedPieceName.equals("R") && copyOfPiece == 3)
                whiteCaptured.addPiece(new Pawn("P", getResources()), playerTurn);
                //Else add the captured piece
            else
                whiteCaptured.addPiece(board[endRow][endCol].piece, playerTurn);
        }
        else {
            for (Pair<Square, Integer> item: blackCaptured.pieces) {
                if (item.first.piece.getName().equals(capturedPieceName))
                    copyOfPiece++;
            }

            if (capturedPieceName.equals("q") && copyOfPiece == 1)
                blackCaptured.addPiece(new Pawn("p", getResources()), playerTurn);
            else if (capturedPieceName.equals("b") && copyOfPiece == 2)
                blackCaptured.addPiece(new Pawn("p", getResources()), playerTurn);
            else if (capturedPieceName.equals("kn") && copyOfPiece == 2)
                blackCaptured.addPiece(new Pawn("p", getResources()), playerTurn);
            else if (capturedPieceName.equals("r") && copyOfPiece == 2)
                blackCaptured.addPiece(new Pawn("p", getResources()), playerTurn);
            else
                blackCaptured.addPiece(board[endRow][endCol].piece, playerTurn);
        }
    }

    //Checks if the game is over
    boolean isGameOver() {
        //If there are no more possible moves, game is over
        if (allValidMoves.size() == 0) {
            return true;
        }

        //wbw stands for white bishop on white square
        //wbb is white bishop on black square
        //(two same color bishops cannot mate, but two opposite color can)
        int piecesLeft = 0, whitePieces = 0, blackPieces = 0;
        int wbw = 0, wbb = 0, bbb = 0, bbw = 0;
        for (Square[] outer: board) {
            for (Square inner : outer) {
                if (inner.isOccupied()) {
                    piecesLeft++;
                    if (inner.piece.getName().equals("B") && (inner.row + inner.col) % 2 == 0) {
                        wbw++;
                        whitePieces++;
                    }
                    else if (inner.piece.getName().equals("B") && (inner.row + inner.col) % 2 == 1){
                        wbb++;
                        whitePieces++;
                    }
                    else if (inner.piece.getName().equals("b") && (inner.row + inner.col) % 2 == 0){
                        bbw++;
                        blackPieces++;
                    }
                    else if (inner.piece.getName().equals("b") && (inner.row + inner.col) % 2 == 1){
                        bbb++;
                        blackPieces++;
                    }
                    else if (inner.piece.getName().equals("KN")){
                        whitePieces++;
                    }
                    else if (inner.piece.getName().equals("kn")){
                        blackPieces++;
                    }
                }
            }
        }

        //Draw conditions:
        //Two kings
        if (piecesLeft == 2) {
            return true;
        }
        //Two kings and one minor piece
        else if (piecesLeft == 3 && (whitePieces + blackPieces) == 1) {
            return true;
        }
        //Two kings and one minor piece on each side
        else if (piecesLeft == 4 && whitePieces == 1 && blackPieces == 1) {
            return true;
        }
        //Two kings and two same colored bishops on one side
        else if (piecesLeft == 4 && (wbw == 2 || wbb == 2 || bbw == 2 || bbb == 2)) {
            return true;
        }
        //Two kings, two same colored bishops on one side and one minor on another
        else if (piecesLeft == 5 && ((wbw == 2 && whitePieces == 2)|| (wbb == 2 && whitePieces == 2)
                || (bbw == 2 && blackPieces == 2)|| (bbb == 2 && blackPieces == 2))) {
            return true;
        }
        //Two kings, two same colored bishops on each side
        else if (piecesLeft == 6 && whitePieces == 2 && blackPieces == 2) {
            if (wbw == 2 && bbw == 2 || wbw == 2 && bbb == 2 ||
                    wbb == 2 && bbw == 2 || wbb == 2 && bbb == 2)
                return true;
        }

        return false;
    }

    //Plays the sound effect for the move
    void playSound() {
        if (gameOver && checkCode != 0) {
            mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_checkmate);
            mediaPlayer.start();
        }
        else if (checkCode != 0){
            mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_check);
            mediaPlayer.start();
        }
        else if (captureFlag) {
            mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_capture);
            mediaPlayer.start();
            captureFlag = false;
        }
        else {
            mediaPlayer = MediaPlayer.create(this.getContext(), R.raw.sound_move);
            mediaPlayer.start();
        }
    }



    //Sets game state to a given turn
    void gameState(int targetTurn) {
        //Prevent going out of bounds
        if (targetTurn > moveList.size() || targetTurn < 0)
            return;

        //Reset to start
        currentTurn[0] = -1;
        board = new Square[ROWS][COLS];
        playerTurn = 0;
        blackCaptured.pieces.clear();
        whiteCaptured.pieces.clear();
        generateBoard();
        setPieces(getResources());

        //Avoid check() going out of bounds
        if (targetTurn <= 2)
            checkCode = 0;

        //Play through until target turn
        for (int index = 0; index < targetTurn; index++) {
            //Generate the check code for the final move
            if (targetTurn > 2 && index == targetTurn - 1) {
                checkCode = check(moveList.get(index)[0], moveList.get(index)[1],
                        moveList.get(index)[2], moveList.get(index)[3]);
            }
            //Make the move
            //Deal with pawn promotion
            if (promotionTrack.containsKey(index + 1)) {
                board[moveList.get(index)[2]][moveList.get(index)[3]].piece = promotionTrack.get(index + 1);
                board[moveList.get(index)[0]][moveList.get(index)[1]].piece = null;
            }
            else {
                int startRow = moveList.get(index)[0];
                int startCol = moveList.get(index)[1];
                int endRow = moveList.get(index)[2];
                int endCol = moveList.get(index)[3];
                String currentPiece = board[startRow][startCol].piece.getName();
                movePiece(startRow, startCol, endRow, endCol, currentPiece);
            }
            //Flag that the piece has moved
            board[moveList.get(index)[2]][moveList.get(index)[3]].piece.hasNotMoved = false;

            //Turn enPassant flag off
            if (enPassant[2] != playerTurn) {
                enPassant[0] = -1;
                enPassant[1] = -1;
                enPassant[2] = -1;
            }

            playerTurn++;
        }

        colorCheck();

        //Highlight squares
        if (playerTurn > 0) {
            board[moveList.get(targetTurn - 1)[0]][moveList.get(targetTurn - 1)[1]].highlight();
            board[moveList.get(targetTurn - 1)[2]][moveList.get(targetTurn - 1)[3]].highlight();
        }

        //Update the legal moves list
        allLegalMoves = legalMoves();
        //Update the valid moves list
        allValidMoves = validMoves(allLegalMoves);
    }

    void endGameMessage(String txt) {
        Toast toast = Toast.makeText(this.getContext(), txt, Toast.LENGTH_LONG);
        toast.getView().setBackgroundColor(Color.LTGRAY);
        TextView v = toast.getView().findViewById(android.R.id.message);
        v.setTextSize(35);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        int squareSize = getWidth() / COLS;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                //Size the square
                board[row][col].tile.set(col * squareSize,
                        row * squareSize,
                        (col + 1) * squareSize,
                        (row + 1) * squareSize);

                //Draw the square
                board[row][col].draw(canvas);

                //Draw the piece
                if (board[row][col].isOccupied()) {
                    canvas.drawBitmap(board[row][col].piece.image, null,
                            board[row][col].tile,null);
                }
            }
        }

        //Draw the promotion window
        if (promotionChoice) {
            //White
            if (playerTurn % 2 == 1) {
                for (int col = 0; col < 4; col++) {
                    //Size the image
                    promotionWhite[col].tile.set((col + 2) * squareSize,
                            9 * squareSize,
                            (col + 3) * squareSize,
                            10 * squareSize);

                    promotionWhite[col].draw(canvas);

                    canvas.drawBitmap(promotionWhite[col].piece.image, null,
                            promotionWhite[col].tile,null);
                }
            }
            //Black
            else {
                for (int col = 0; col < 4; col++) {
                    //Size the image
                    promotionBlack[col].tile.set((col + 2) * squareSize,
                            9 * squareSize,
                            (col + 3) * squareSize,
                            10 * squareSize);

                    promotionBlack[col].draw(canvas);

                    canvas.drawBitmap(promotionBlack[col].piece.image, null,
                            promotionBlack[col].tile,null);
                }
            }
        }

        //White
        if (blackCaptured.pieces.size() > 0) {
            for (int col = 0; col < blackCaptured.pieces.size(); col++) {
                //Size the image
                double imageStep = col / 1.75;
                int left = (int) (imageStep * (squareSize / 2));
                int right = (int) ((imageStep + 1) * (squareSize / 2));
                blackCaptured.pieces.get(col).first.tile.set( left, 8 * squareSize,
                         right, (int) (8.5 * squareSize));

                blackCaptured.pieces.get(col).first.draw(canvas);

                canvas.drawBitmap(blackCaptured.pieces.get(col).first.piece.image, null,
                        blackCaptured.pieces.get(col).first.tile,null);
            }
        }
        //Black
        if (whiteCaptured.pieces.size() > 0) {
            for (int col = 0; col < whiteCaptured.pieces.size(); col++) {
                //Size the image
                double imageStep = col / 1.75;
                int left = (int) (squareSize * 8 - (imageStep + 1) * (squareSize / 2));
                int right = (int) (squareSize * 8 - imageStep * (squareSize / 2));
                whiteCaptured.pieces.get(col).first.tile.set(left, (int) (8.5 * squareSize),
                        right, 9 * squareSize);

                whiteCaptured.pieces.get(col).first.draw(canvas);

                canvas.drawBitmap(whiteCaptured.pieces.get(col).first.piece.image, null,
                        whiteCaptured.pieces.get(col).first.tile,null);
            }
        }


    }

    //Computer
    //Computer
    //Computer
    //Computer
    //Computer

    void computerTurn() {
        //Go to deeper depth as the number of pieces decreases
        if (whiteCaptured.pieces.size() + blackCaptured.pieces.size() < 20) {
            vsComputer = 4;
        }
        else if (whiteCaptured.pieces.size() + blackCaptured.pieces.size() >= 20 &&
                whiteCaptured.pieces.size() + blackCaptured.pieces.size() < 30) {
            vsComputer = 5;
        }
        else if (whiteCaptured.pieces.size() + blackCaptured.pieces.size() >= 30) {
            vsComputer = 6;
        }

        Pair<Integer[], Integer> compTurn = chooseMove(vsComputer);
        moveScores.clear();

        int startRow = compTurn.first[0];
        int startCol = compTurn.first[1];
        int endRow = compTurn.first[2];
        int endCol = compTurn.first[3];
        String currentPiece = board[startRow][startCol].piece.getName();
        checkCode = compTurn.second;
        board[startRow][startCol].highlight();

        movePiece(startRow, startCol, endRow, endCol, currentPiece);

        //Computer pawn promotion (goes to queen only)
        if (currentPiece.equals("P") && endRow == 0) {
            Resources resources = getResources();
            board[endRow][endCol].piece = new Queen("Q", resources);
            board[endRow][endCol].piece.player = 0;

            //check if the promotion causes check by simulating the move
            board[startRow][startCol].piece = new Queen("Q", resources);
            board[endRow][endCol].piece.player = 0;
            check(startRow, startCol, endRow, endCol);
            board[startRow][startCol].piece = null;
        }
        else if (currentPiece.equals("p") && endRow == 7) {
            Resources resources = getResources();
            board[endRow][endCol].piece = new Queen("q", resources);
            board[endRow][endCol].piece.player = 1;

            //check if the promotion causes check by simulating the move
            board[startRow][startCol].piece = new Queen("q", resources);
            board[endRow][endCol].piece.player = 1;
            check(startRow, startCol, endRow, endCol);
            board[startRow][startCol].piece = null;
        }

        //Unhighlight previous move
        if (playerTurn > 0) {
            board[moveList.get(playerTurn - 1)[0]][moveList.get(playerTurn - 1)[1]].unhighlight();
            board[moveList.get(playerTurn - 1)[2]][moveList.get(playerTurn - 1)[3]].unhighlight();
        }
        //Highlight move
        colorCheck();
        board[startRow][startCol].highlight();
        board[endRow][endCol].highlight();

        //Turn enPassant flag off
        if (enPassant[2] != playerTurn) {
            enPassant[0] = -1;
            enPassant[1] = -1;
            enPassant[2] = -1;
        }

        //Add the move to moveList
        moveList.add(Arrays.copyOf(compTurn.first, 4));

        playerTurn++;
        //Update the legal moves list
        allLegalMoves = legalMoves();
        //Update the valid moves list
        allValidMoves = validMoves(allLegalMoves);

        //Check if game is over
        gameOver = isGameOver();

        if (gameOver) {
            ((Activity) getContext()).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (checkCode == 0)
                        endGameMessage("Draw!");
                    else
                        endGameMessage("Checkmate!");
                }
            });
        }

        playSound();
        this.invalidate();
    }

    Pair<Integer[], Integer> chooseMove(int depth) {
        //Use book opening if possible
        if (moveList.size() < 4) {
            Pair<Integer[], Integer> move;
            Book book = new Book(moveList);
            switch(moveList.size()) {
                //Not implemented for white
                case 0: break;
                //Black first move
                case 1:
                    move = book.blackFirst();
                    if (move != null)
                        return move;
                    break;
                //Not implemented for white
                case 2: break;
                case 3:
                    move = book.blackSecond();
                    if (move != null)
                        return move;
                    break;
            }
        }

        //Find all valid moves
        ArrayList<Integer[]> engine_allLegalMoves = legalMoves();
        ArrayList<Pair<Integer[], Integer>> engine_allValidMoves = validMoves(engine_allLegalMoves);

        ArrayList<Pair<Pair<Integer[], Integer>, Integer>> moveOptions = new ArrayList<>();
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        int alpha = -100000;
        int beta = 100000;
        int currentValue;

        //For each move...
        for (Pair<Integer[], Integer> move: engine_allValidMoves) {
            //Move the piece
            Piece temp = board[move.first[2]][move.first[3]].piece;
            String name = board[move.first[0]][move.first[1]].getPiece();
            boolean hasNotMoved = board[move.first[0]][move.first[1]].piece.hasNotMoved;
            board[move.first[2]][move.first[3]].piece = board[move.first[0]][move.first[1]].piece;
            board[move.first[0]][move.first[1]].piece = null;

            //White computer minimax
            if (playerTurn % 2 == 0) {
                currentValue = min(depth - 1, alpha, beta, move.second);

                //Score bonuses
                //Negative score for moving a piece twice in the early game
                if (hasNotMoved && moveList.size() < 20)
                    currentValue += 25;
                //If the move is a castle, +50 value
                if (name.equals("K") && Math.abs(move.first[1] - move.first[3]) == 2)
                    currentValue += 50;
                //Negative score for moving a rook or king while castling is an option
                else if (name.equals("R") && hasNotMoved &&
                        board[whiteKing[0]][whiteKing[1]].piece.hasNotMoved &&
                        moveList.size() < 30) {
                    currentValue -= 25;
                }
                else if (name.equals("K") && hasNotMoved  &&
                        moveList.size() < 40) {
                    currentValue -= 75;
                }
                //If the move ends with black king in check, +15 value
                if (move.second == 3)
                    currentValue += 15;
                //Negative score for moving the queen or rook early
                if ((name.equals("Q") || name.equals("R")) && moveList.size() < 16)
                    currentValue -= 30;

                currentValue += eval.pawnStructure();

                //If the value of the current move is greater than the max, update max
                if (currentValue > max) {
                    max = currentValue;
                }
            }
            //Black computer minimax (Negative is a good move)
            else {
                currentValue = max(depth - 1, alpha, beta, move.second);

                //Score bonuses
                //Negative score for moving a piece twice in the early game
                if (hasNotMoved && moveList.size() < 20)
                    currentValue -= 25;
                //If the move is a castle, -50 value
                if (name.equals("k") && Math.abs(move.first[1] - move.first[3]) == 2) {
                    currentValue -= 50;
                }
                //Negative score for moving a rook or king while castling is an option
                else if (name.equals("r") && hasNotMoved &&
                        board[blackKing[0]][blackKing[1]].piece.hasNotMoved  &&
                        moveList.size() < 30) {
                    currentValue += 25;
                }
                else if (name.equals("k") && hasNotMoved  &&
                        moveList.size() < 40) {
                    currentValue += 75;
                }
                //If the move ends with white king in check, -15 value
                if (move.second == 2)
                    currentValue -= 15;
                //Negative score for moving the queen or rook early
                if ((name.equals("q") || name.equals("r")) && moveList.size() < 16)
                    currentValue += 30;

                eval.pawnStructure();

                //If the value of the current move is less than the min, update min
                if (currentValue < min) {
                    min = currentValue;
                }
            }

            //Undo the move
            board[move.first[0]][move.first[1]].piece = board[move.first[2]][move.first[3]].piece;
            board[move.first[2]][move.first[3]].piece = temp;

            //Add the move and its score
            moveOptions.add(new Pair<> (move, currentValue));
        }

        //Prune moveOptions so only moves within 20 pts of the best remain
        Iterator itr = moveOptions.iterator();
        while (itr.hasNext()) {
            Pair<Pair<Integer[], Integer>, Integer> item =
                    (Pair<Pair<Integer[], Integer>, Integer>)itr.next();
            if (playerTurn % 2 == 0 && item.second + 20 < max)
                itr.remove();
            else if (playerTurn % 2 == 1 && item.second - 20 > min)
                itr.remove();
        }
        for (Pair<Pair<Integer[], Integer>, Integer> item : moveOptions)
            System.out.println("Move: " + Arrays.toString(item.first.first) + ", score: " + item.second);
        //Choose a random move from the options list
        Random rand = new Random();
        int next = rand.nextInt(moveOptions.size());

        return moveOptions.get(next).first;
    }

    int min(int depth, int alpha, int beta, int checkState) {
        //If at the target depth, give the score of the current board
        if (depth == 0) {
            return eval.evaluate(board,
                    whiteCaptured.pieces.size() + blackCaptured.pieces.size());
        }

        playerTurn++;
        ArrayList<Integer[]> engine_allLegalMoves = legalMoves();
        ArrayList<Pair<Integer[], Integer>> engine_allValidMoves = validMoves(engine_allLegalMoves);

        if (engine_allValidMoves.isEmpty()) {
            playerTurn--;

            //If black is in checkmate
            if (checkState == 3)
                return 6000 + depth * 300;
            //White in checkmate
            else if (checkState == 2)
                return -6000 - depth * 300;

            return 0;
        }

        int min = Integer.MAX_VALUE;
        for (Pair<Integer[], Integer> move: engine_allValidMoves) {

            Piece temp = board[move.first[2]][move.first[3]].piece;
            board[move.first[2]][move.first[3]].piece = board[move.first[0]][move.first[1]].piece;
            board[move.first[0]][move.first[1]].piece = null;

            min = Math.min(min, max(depth - 1, alpha, beta, move.second));


            board[move.first[0]][move.first[1]].piece = board[move.first[2]][move.first[3]].piece;
            board[move.first[2]][move.first[3]].piece = temp;

            beta = Math.min(min, beta);
            if (beta <= alpha) {
                playerTurn--;
                return min;
            }
        }

        playerTurn--;
        return min;
    }

    int max(int depth, int alpha, int beta, int checkState) {
        if (depth == 0) {
            return eval.evaluate(board,
                    whiteCaptured.pieces.size() + blackCaptured.pieces.size());
        }

        playerTurn++;
        ArrayList<Integer[]> engine_allLegalMoves = legalMoves();
        ArrayList<Pair<Integer[], Integer>> engine_allValidMoves = validMoves(engine_allLegalMoves);

        if (engine_allValidMoves.isEmpty()) {
            playerTurn--;
            //If white is in checkmate
            if (checkState == 2)
                return -6000 - depth * 300;
            //Black in checkmate
            else if (checkState == 3)
                return 6000 + depth * 300;
            //Draw
            return 0;
        }

        int max = Integer.MIN_VALUE;
        for (Pair<Integer[], Integer> move: engine_allValidMoves) {
            Piece temp = board[move.first[2]][move.first[3]].piece;
            board[move.first[2]][move.first[3]].piece = board[move.first[0]][move.first[1]].piece;
            board[move.first[0]][move.first[1]].piece = null;

            max = Math.max(max, min(depth - 1, alpha, beta, move.second));

            board[move.first[0]][move.first[1]].piece = board[move.first[2]][move.first[3]].piece;
            board[move.first[2]][move.first[3]].piece = temp;

            alpha = Math.max(max, alpha);
            if (beta <= alpha) {
                playerTurn--;
                return max;
            }
        }

        playerTurn--;
        return max;
    }
}