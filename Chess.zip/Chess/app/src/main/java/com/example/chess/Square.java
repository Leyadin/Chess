package com.example.chess;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class Square {
    int row, col;
    Rect tile;
    Piece piece;
    private Paint tileColor;

    Square(int _row, int _col) {
        this.row = _row;
        this.col = _col;
        this.tile = new Rect();
        this.piece = null;

        this.tileColor = new Paint();
        //Captured piece square
        if (row == -1 && col == -1)
            tileColor.setColor(Color.TRANSPARENT);
        //White square
        else if ((row + col) % 2 == 0)
            tileColor.setColor(Color.WHITE);
        //Dark square
        else
            tileColor.setColor(Color.rgb(186,116,76));
    }

    boolean isTouched(final int x, final int y) {
        return tile.contains(x, y);
    }

    void highlight() {
        if ((row + col) % 2 == 0)
            tileColor.setColor(Color.rgb(220,220,46));
        else
            tileColor.setColor(Color.rgb(190,190,30));
    }

    void unhighlight() {if ((row + col) % 2 == 0)
            tileColor.setColor(Color.WHITE);
        else
            tileColor.setColor(Color.rgb(186,116,76));
    }

    void colorChecked() {
        tileColor.setColor(Color.RED);
    }

    void uncolorChecked() {
        if ((row + col) % 2 == 0)
            tileColor.setColor(Color.WHITE);
        else
            tileColor.setColor(Color.rgb(186,116,76));
    }

    boolean isOccupied() {
        return !(piece == null);
    }

    String getPiece() {return !(piece == null) ? piece.getName() : "empty";}

    public void draw(Canvas canvas) {
        canvas.drawRect(tile, tileColor);
    }

}