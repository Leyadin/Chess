package com.example.chess;

import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;


public class MainActivity extends AppCompatActivity {

    Board game;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        setContentView(R.layout.activity_main);

        int height = Resources.getSystem().getDisplayMetrics().heightPixels;

        game = new Board(this);
        LinearLayout.LayoutParams gameLayout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        gameLayout.setMargins(0, height / 10,0, height / 10);
        addContentView(game, gameLayout);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //Prevent screen interaction while the computer is thinking
        if (game.lockScreen)
            return false;

        int[] coords = new int[2];
        game.getLocationInWindow(coords);

        int touchX = (int) event.getX() - coords[0];
        int touchY = (int) event.getY() - coords[1];

        switch(event.getAction()){
            case MotionEvent.ACTION_DOWN:
                game.playGame(touchX, touchY);
                game.invalidate();
                break;
            case MotionEvent.ACTION_UP:
                break;
            case MotionEvent.ACTION_MOVE:
                break;
        }
        return true;
    }

    public void onClickNewGame(View v)
    {
        game.init();
        game.invalidate();
    }

    public void onClickCompGame(View v)
    {
        game.init();
        game.computerOn();
        game.invalidate();
    }

    public void onClickBack(View v)
    {
        if (game.vsComputer != 0 && !game.gameOver)
            game.gameState(game.playerTurn - 2);
        else
            game.gameState(game.playerTurn - 1);
        game.invalidate();
    }

    public void onClickForward(View v)
    {
        if (game.vsComputer != 0 && !game.gameOver)
            game.gameState(game.playerTurn + 2);
        else
            game.gameState(game.playerTurn + 1);
        game.invalidate();
    }

    public void onClickFirst(View v)
    {
        game.gameState(0);
        game.invalidate();
    }

    public void onClickLast(View v)
    {
        game.gameState(game.moveList.size());
        game.invalidate();
    }


}
