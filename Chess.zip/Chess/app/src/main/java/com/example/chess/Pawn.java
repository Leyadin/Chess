package com.example.chess;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

class Pawn extends Piece {
    Pawn(String _name, Resources r) {
        super(_name);
        this.value = 100;

        if (player == 0)
            image = BitmapFactory.decodeResource(r, R.drawable.w_p);
        else
            image = BitmapFactory.decodeResource(r, R.drawable.b_p);
    }

    @Override
    boolean isCorrectTurn(int playerTurn) {
        if (playerTurn % 2 == 0 && Character.isUpperCase(name.charAt(0)))
            return true;
        else if (playerTurn % 2 == 1 && Character.isLowerCase(name.charAt(0)))
            return true;
        else
            return false;
    }

    @Override
    boolean isLegalMove(int rowStart, int colStart, int rowEnd, int colEnd) {
        //White pawn
        if (name == "P") {
            if (Math.abs(colEnd - colStart) <= 1 && rowEnd - rowStart == -1)
                return true;
            else if (rowStart == 6 && rowEnd == 4 && colEnd == colStart)
                return true;
            else
                return false;
        }
        //Black pawn
        else {
            if (Math.abs(colEnd - colStart) <= 1 && rowEnd - rowStart == 1)
                return true;
            else if (rowStart == 1 && rowEnd == 3 && colEnd == colStart)
                return true;
            else
                return false;
        }

    }

    @Override
    ArrayList<Integer> movePath(int rowStart, int colStart, int rowEnd, int colEnd) {
        ArrayList<Integer> path = new ArrayList<>();

        path.add(rowStart);
        path.add(colStart);

        //White - move 2 from starting position
        if (rowEnd - rowStart == 2) {
            path.add(rowStart + 1);
            path.add(colStart);
            path.add(rowEnd);
            path.add(colEnd);
        }
        //Black - move 2 from starting position
        else if (rowEnd - rowStart == -2) {
            path.add(rowStart - 1);
            path.add(colStart);
            path.add(rowEnd);
            path.add(colEnd);
        }
        //All other pawn moves
        else {
            path.add(rowEnd);
            path.add(colEnd);
        }

        return path;
    }

    @Override
    ArrayList<Integer[]> allLegalMoves(int rowStart, int colStart) {
        ArrayList<Integer[]> moveList = new ArrayList<>();

        //White
        if (player == 0) {
            //Up 1
            Integer[] up = {rowStart, colStart, rowStart - 1, colStart};
            //Prevent from going out of bounds
            if (up[2] >= 0)
                moveList.add(up);
            //Up 2 if having not moved
            if (rowStart == 6) {
                Integer[] up2 = {rowStart, colStart, rowStart - 2, colStart};
                moveList.add(up2);
            }
            //Diagonal Capture
            Integer[] diagLeft = {rowStart, colStart, rowStart - 1, colStart - 1};
            if (diagLeft[2] >= 0 && diagLeft[3] >= 0)
                moveList.add(diagLeft);
            Integer[] diagRight = {rowStart, colStart, rowStart - 1, colStart + 1};
            if (diagRight[2] >= 0 && diagRight[3] <= 7)
                moveList.add(diagRight);
        }

        //Black
        if (player == 1) {
            //Down 1
            Integer[] down = {rowStart, colStart, rowStart + 1, colStart};
            //Prevent from going out of bounds
            if (down[2] <= 7)
                moveList.add(down);
            //Down 2 if having not moved
            if (rowStart == 1) {
                Integer[] down2 = {rowStart, colStart, rowStart + 2, colStart};
                moveList.add(down2);
            }
            //Diagonal Capture
            Integer[] diagLeft = {rowStart, colStart, rowStart + 1, colStart - 1};
            if (diagLeft[2] <= 7 && diagLeft[3] >= 0)
                moveList.add(diagLeft);
            Integer[] diagRight = {rowStart, colStart, rowStart + 1, colStart + 1};
            if (diagRight[2] <= 7 && diagRight[3] <= 7)
                moveList.add(diagRight);
        }

        return moveList;
    }
}
